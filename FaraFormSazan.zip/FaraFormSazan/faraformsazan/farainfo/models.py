from django.db import models

class info(models.Model):
    title = models.TextField()
    name = models.CharField(max_length=60)
    post = models.TextField()
    data = models.DateField()
    
    def __str__(self):
        return self.title
