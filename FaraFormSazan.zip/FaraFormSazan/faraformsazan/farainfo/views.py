from django.shortcuts import render
from .models import info


def Home(request):
    return render(request, 'index.html')

def FaraNews(request):
    return render(request, 'faranews.html')

def FaraNews(request):
    zarf = info.objects.all()
    return render(request, 'faranews.html', {'zarf': zarf})