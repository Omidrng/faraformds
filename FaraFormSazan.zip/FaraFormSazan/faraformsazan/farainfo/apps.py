from django.apps import AppConfig


class FarainfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'farainfo'
